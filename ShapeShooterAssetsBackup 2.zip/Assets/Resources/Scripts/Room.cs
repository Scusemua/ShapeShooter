﻿using UnityEngine;
using System.Collections;

public class Room : MonoBehaviour {

    // Array of all the enemies in the room.
    public BaseEnemy[] enemies;

    // References to walls which are placed in the absence of doors.
    private GameObject horizontalWall;
    private GameObject verticalWall;

    // Coordinates of the room in the world. 
    public float x, y;
    // Coordinates of the room in the matrix.
    public int xMatrix, yMatrix;

    // ID number of the room.
    public int roomID;

    public byte doorsDebug; 

    // Reference to the Floor GameObject.
    private Floor floor;

    /// <summary>
    /// Returns the associated entry in the floor's room matrix (which holds onto the doors as well as a bit indicating whether or not the given room is special).
    /// 
    /// The zero'th bit indicates whether or not there exists a door on the west wall.
    /// The first bit indicates whether or not there exists a door on the east wall. 
    /// The second bit indicates whether or not there exists a door on the south wall.
    /// The third bit indicates whether or not there exists a door on the north wall.
    /// The fourth bit indicates whether or not the room is a special room.
    /// </summary>
    public byte Doors
    {
        get
        {
            if (floor == null)
            {
                floor = GameObject.FindGameObjectWithTag("Floor").GetComponent<Floor>();
            }
            return floor.roomsMatrix[xMatrix, yMatrix];
        }
        set
        {
            if (floor == null)
            {
                floor = GameObject.FindGameObjectWithTag("Floor").GetComponent<Floor>();
            }
            floor.SetMatrixEntry(xMatrix, yMatrix, value);
        }
    }

	// Use this for initialization
	void Start () {
        floor = GameObject.FindGameObjectWithTag("Floor").GetComponent<Floor>();
    }
	
	// Update is called once per frame
	void Update () {

	}

    /// <summary>
    /// Returns true if all enemies in this room are dead, otherwise returns false.
    /// </summary>
    public bool IsRoomClear()
    {
        // Iterate through the array of enemies checking if each enemy is alive. If any enemy is alive, immediately return false.
        foreach (BaseEnemy b in enemies)
        {
            if (b.IsAlive()) return false;
        }
        return true;
    }

    /// <summary>
    /// Function to be called once the doors array has been set up from outside the class.
    /// This function uses the doors array to place doors/walls in the appropriate places.
    /// </summary>
    public void PlaceDoors()
    {
        horizontalWall = Resources.Load("Prefabs/Floor/HorizontalWall") as GameObject;
        verticalWall = Resources.Load("Prefabs/Floor/VerticalWall") as GameObject;
        // Again, the order of the bool in the doors array is North, South, East, West.
        if ((Doors & (1 << 3)) == 0) // North
        {
            // Debug.Log("Placing wall on Northern wall.");
            GameObject wall = Instantiate(horizontalWall, this.transform.position + new Vector3(0, 8, 0), this.transform.rotation) as GameObject;
            GUIText t = wall.AddComponent<GUIText>();
            t.text = "This was added by Room " + roomID;
        }

        if ((Doors & (1 << 2)) == 0) // South
        {
            // Debug.Log("Placing wall on Southern wall.");
            GameObject wall = Instantiate(horizontalWall, this.transform.position + new Vector3(0, -8, 0), this.transform.rotation) as GameObject;
            GUIText t = wall.AddComponent<GUIText>();
            t.text = "This was added by Room " + roomID;
        }

        if ((Doors & (1 << 1)) == 0) // East
        {
            // Debug.Log("Placing wall on Eastern wall.");
            GameObject wall = Instantiate(verticalWall, this.transform.position + new Vector3(8, 0, 0), this.transform.rotation) as GameObject;
            GUIText t = wall.AddComponent<GUIText>();
            t.text = "This was added by Room " + roomID;
        }

        if ((Doors & 1) == 0) // West
        {
            // Debug.Log("Placing wall on Western wall.");
            GameObject wall = Instantiate(verticalWall, this.transform.position + new Vector3(-8, 0, 0), this.transform.rotation) as GameObject;
            GUIText t = wall.AddComponent<GUIText>();
            t.text = "This was added by Room " + roomID;
        }
    }

    /// <summary>
    /// Returns the key which is used to store the room in the roomsHash.
    /// </summary>
    public string GenerateRoomHash()
    {
        return "(" + xMatrix + "," + yMatrix + ")";
    }
}
