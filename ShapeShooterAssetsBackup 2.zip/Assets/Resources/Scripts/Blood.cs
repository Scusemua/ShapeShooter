﻿using UnityEngine;
using System.Collections;

public class Blood : MonoBehaviour {

	// Use this for initialization
	void Start () {
        int bloodType = Random.Range(1, 4);
        switch (bloodType)
        {
            case 1:
                GetComponent<SpriteRenderer>().sprite = Resources.Load("Sprites/FX/blood", typeof(Sprite)) as Sprite;
                break;
            case 2:
                GetComponent<SpriteRenderer>().sprite = Resources.Load("Sprites/FX/blood2", typeof(Sprite)) as Sprite;
                break;
            case 3:
                GetComponent<SpriteRenderer>().sprite = Resources.Load("Sprites/FX/blood3", typeof(Sprite)) as Sprite;
                break;
        }
	}
	
}
