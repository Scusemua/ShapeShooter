﻿using UnityEngine;
using System.Collections;

public abstract class BaseEnemy : MonoBehaviour {

    public enum STATE { LIVING, DECEASED };

    protected float movementSpeed;
    protected float maxHealth;
    protected float health;
    protected GameObject player;

    public GameObject blood;
    public bool showHealth = true;
    public STATE state;

    /// <summary>
    /// Called within the Start() method of child classes.
    /// </summary>
    protected void Create()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        state = STATE.LIVING;
    }

    void OnGUI()
    {
        if (!showHealth) return;
        Vector2 targetPos = Camera.main.WorldToScreenPoint(transform.position);
        GUI.Box(new Rect(targetPos.x, Screen.height - targetPos.y, 60, 20), health + "/" + maxHealth);
    }

    /// <summary>
    /// Function which handles bullets/projectiles colliding with this enemy.
    /// </summary>
    /// <param name="damage">The damage of the bullet (its a field of the bullet which collided with this enemy).</param>
    public void DoBulletCollision(float damage)
    {
        health -= damage;
        if (health <= 0)
        {
            Die();
        }
    }

    /// <summary>
    /// Function which handles the death of this enemy.
    /// </summary>
    void Die()
    {
        state = STATE.DECEASED;
        Instantiate(blood, this.transform.position, this.transform.rotation);
        Destroy(gameObject);
    }

    /// <summary>
    /// Returns true if this enemy is still alive, otherwise returns false.
    /// </summary>
    public bool IsAlive()
    {
        return state == STATE.LIVING;
    }

}
