﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Floor : MonoBehaviour {

    // Represents the current floor the player is on. The current floor impacts how many rooms there are.
    private int currentFloor;

    // The basic room (to be filled with enemies).
    private GameObject roomBase;

    // List of all the rooms.
    public IList<Room> rooms;

    // List of coordinate-pairs already occupied.
    private IList<Tuple<float, float>> coordinates;

    // Shape Shooter title text.
    public GameObject titleText;

    // Reference to the Player GameObject.
    public GameObject player;

    // References to the GameObjects of enemies.
    public BasicEnemy basicEnemy;
    public GameObject fastEnemy;
    public GameObject tankEnemy;

    // Size of a room.
    private Vector3 roomSize;

	// Initializes appropriate variables.
	void Start () {
        currentFloor = 1; // We begin on the first floor (one-indexed).
        roomBase = Resources.Load("Prefabs/Floor/Room") as GameObject;
        roomSize = roomBase.transform.FindChild("Quad").GetComponent<Renderer>().bounds.size;
        coordinates = new List<Tuple<float, float>>();
        GenerateRooms();
    }

    // Algorithm which generates the layout for the current floor.
    void GenerateRooms()
    {
        int numRooms = CalculateNumberOfRooms(currentFloor);
        int roomID = 0;
        rooms = new List<Room>();
        GameObject firstGO = Instantiate(roomBase);
        Room first = firstGO.AddComponent<Room>();
        first.roomID = roomID++;
        first.x = this.transform.position.x;
        first.y = this.transform.position.y;
        first.doors = new bool[4];
        rooms.Add(first);
        for (int i = 0; i < numRooms; i++)
        {
            GameObject newRoomGO = Instantiate(roomBase);
            Room newRoom = newRoomGO.AddComponent<Room>();
            newRoom.roomID = roomID++;
            bool done = false;
            while (!done)
            {
                // Pick a random room from the list of rooms. We will place this new room next to it.
                int index = Random.Range(0, rooms.Count);
                // This is the direction in which we will add the room. Note that if this fails, 
                // we will try again, though we may pick a different room all together.
                int direction = Random.Range(0, 4);
                switch (direction)
                {
                    case 0: // North
                        if (rooms[index].North == null)
                        {
                            // Adjust the data of the new room. 
                            newRoom.doors = new bool[4];
                            // Since we're adding the new room to the north wall of the existing room,
                            // we set doors[1] value of the new room to true since that corresponds to south.
                            newRoom.doors[1] = true;
                            newRoom.South = rooms[index];
                            // Adjust the x and y coordinates of the new room using data from the old room.
                            newRoom.x = rooms[index].x;
                            newRoom.y = rooms[index].y + roomSize.y;
                            // Update the coordinates list (used to prevent two rooms from being generated atop one-another).
                            Tuple<float, float> cords = new Tuple<float, float>(newRoom.x, newRoom.y);
                            coordinates.Add(cords);
                            // Adjust the data of the room to which we're appending the new room.
                            rooms[index].North = newRoom;
                            // Since we are adding the new room to the North wall of the existing room, doors[0] needs to be true.
                            rooms[index].doors[0] = true;
                            rooms.Add(newRoom);
                            Debug.Log("Adding Room " + newRoom.roomID + " to the North wall of Room " + rooms[index].roomID + ".");
                            done = true;
                        }
                        break;
                    case 1: // South
                        if (rooms[index].South == null)
                        {
                            // Adjust the data of the new room. 
                            newRoom.doors = new bool[4];
                            // Since we're adding the new room to the south wall of the existing room,
                            // we set doors[0] value of the new room to true since that corresponds to north.
                            newRoom.doors[0] = true;
                            newRoom.North = rooms[index];
                            // Adjust the x and y coordinates of the new room using data from the old room.
                            newRoom.x = rooms[index].x;
                            newRoom.y = rooms[index].y - roomSize.y;
                            // Update the coordinates list (used to prevent two rooms from being generated atop one-another).
                            Tuple<float, float> cords = new Tuple<float, float>(newRoom.x, newRoom.y);
                            coordinates.Add(cords);
                            // Adjust the data of the old room. Since we're adding the new room to the south, set the doors[1] field
                            // of the existing room to true since there needs to be a door there.
                            rooms[index].South = newRoom;
                            rooms[index].doors[1] = true;
                            rooms.Add(newRoom);
                            Debug.Log("Adding Room " + newRoom.roomID + " to the North wall of Room " + rooms[index].roomID + ".");
                            done = true;
                        }
                        break;
                    case 2: // East
                        if (rooms[index].East == null)
                        {
                            // Adjust the data of the new room.
                            newRoom.doors = new bool[4];
                            // Since we're adding the new room to the East wall of the existing room, there 
                            // will need to be a door on the west wall of the new room, so set doors[3] to true. 
                            newRoom.doors[3] = true;
                            newRoom.West = rooms[index];
                            // Adjust the x and y coordinates of the new room based on the coordinates of the existing room.
                            newRoom.x = rooms[index].x + roomSize.x;
                            newRoom.y = rooms[index].y;
                            // Update the coordinates list (used to prevent two rooms from being generated atop one-another).
                            Tuple<float, float> cords = new Tuple<float, float>(newRoom.x, newRoom.y);
                            coordinates.Add(cords);
                            // Adjust the data of the existing room.
                            rooms[index].East = newRoom;
                            // Since we're adding the new room to the East wall of the old room, doors[2] needs to be true.
                            rooms[index].doors[2] = true;
                            rooms.Add(newRoom);
                            Debug.Log("Adding Room " + newRoom.roomID + " to the East wall of Room " + rooms[index].roomID + ".");
                            done = true;
                        }
                        break;
                    case 3: // West
                        if (rooms[index].West == null)
                        {
                            // Adjust the data of the new room.
                            newRoom.doors = new bool[4];
                            // Since we're adding the new room to the West wall of the existing room, we need to set 
                            // doors[2] of the new room to true, since we're going to need a door on the East side of the new room.
                            newRoom.doors[2] = true;
                            newRoom.East = rooms[index];
                            // Adjust the x and y coordinates of the new room based on the coordinates of the existing room.
                            newRoom.x = rooms[index].x - roomSize.x;
                            newRoom.y = rooms[index].y;
                            // Update the coordinates list (used to prevent two rooms from being generated atop one-another).
                            Tuple<float, float> cords = new Tuple<float, float>(newRoom.x, newRoom.y);
                            coordinates.Add(cords);
                            // Adjust the data of the existing room.
                            rooms[index].West = newRoom;
                            // Since we're adding the new room to the East wall of the old room, doors[3] needs to be true.
                            rooms[index].doors[3] = true;
                            rooms.Add(newRoom);
                            Debug.Log("Adding Room " + newRoom.roomID + " to the West wall of Room " + rooms[index].roomID + ".");
                            done = true;
                        }
                        break;
                }
            }
        }
        // Move the rooms into their proper positions and place the doors.
        foreach (Room r in rooms)
        {
            // Create a reference to the game object to which the room is attached.
            GameObject gameObject = r.gameObject;
            // Adjust the room's position via the transform.position field.
            gameObject.transform.position = new Vector3(r.x, r.y, 0);
            // Place the doors appropriately.
            r.PlaceDoors();
        }
        // Instantiate the player. 
        Player playerInstantiated = Instantiate(player, this.transform.position, Quaternion.identity) as Player;
        // If we're on the first floor, then instantiate the title text.
        if (currentFloor == 1) Instantiate(titleText, new Vector3(0, 4, 0), Quaternion.identity);
    }

    // The length/width of the floor array is the floor number multiplied by ten
    // plus or minus two times a random number between one and the floor number.
    int CalculateNumberOfRooms(int floor)
    {
        return (floor * 10) + Random.Range(1, floor);
    }

    private class Tuple<T, K>
    {
        T first;
        K second;

        public Tuple(T t, K k)
        {
            first = t;
            second = k;
        }

        public T First
        {
            get
            {
                return first;
            }
            set
            {
                first = value;
            }
        }

        public K Second
        {
            get
            {
                return second;
            }
            set
            {
                second = value;
            }
        }
    }
}
