﻿using UnityEngine;
using System.Collections;

public class Room : MonoBehaviour {

    // Array of all the enemies in the room.
    public BaseEnemy[] enemies;
    // Array of bool indicating whether or not a door should be placed. The order is North, South, East, West. 
    public bool[] doors;

    // References to walls which are placed in the absence of doors.
    private GameObject horizontalWall;
    private GameObject verticalWall;

    // References to adjacent rooms in the respective direction.
    public Room North, South, East, West;

    // Coordinates of the room.
    public float x, y;

    // ID number of the room.
    public int roomID;

	// Use this for initialization
	void Start () { 

    }
	
	// Update is called once per frame
	void Update () {

	}

    /// <summary>
    /// Returns true if all enemies in this room are dead, otherwise returns false.
    /// </summary>
    public bool IsRoomClear()
    {
        // Iterate through the array of enemies checking if each enemy is alive. If any enemy is alive, immediately return false.
        foreach (BaseEnemy b in enemies)
        {
            if (b.IsAlive()) return false;
        }
        return true;
    }

    /// <summary>
    /// Function to be called once the doors array has been set up from outside the class.
    /// This function uses the doors array to place doors/walls in the appropriate places.
    /// </summary>
    public void PlaceDoors()
    {
        horizontalWall = Resources.Load("Prefabs/Floor/HorizontalWall") as GameObject;
        verticalWall = Resources.Load("Prefabs/Floor/VerticalWall") as GameObject;
        // Again, the order of the bool in the doors array is North, South, East, West.
        if (doors[0] == false) // North
        {
            // Debug.Log("Placing wall on Northern wall.");
            GameObject wall = Instantiate(horizontalWall, this.transform.position + new Vector3(0, 8, 0), this.transform.rotation) as GameObject;
            GUIText t = wall.AddComponent<GUIText>();
            t.text = "This was added by Room " + roomID;
        }

        if (doors[1] == false) // South
        {
            // Debug.Log("Placing wall on Southern wall.");
            GameObject wall = Instantiate(horizontalWall, this.transform.position + new Vector3(0, -8, 0), this.transform.rotation) as GameObject;
            GUIText t = wall.AddComponent<GUIText>();
            t.text = "This was added by Room " + roomID;
        }

        if (doors[2] == false) // East
        {
            // Debug.Log("Placing wall on Eastern wall.");
            GameObject wall = Instantiate(verticalWall, this.transform.position + new Vector3(8, 0, 0), this.transform.rotation) as GameObject;
            GUIText t = wall.AddComponent<GUIText>();
            t.text = "This was added by Room " + roomID;
        }

        if (doors[3] == false) // West
        {
            // Debug.Log("Placing wall on Western wall.");
            GameObject wall = Instantiate(verticalWall, this.transform.position + new Vector3(-8, 0, 0), this.transform.rotation) as GameObject;
            GUIText t = wall.AddComponent<GUIText>();
            t.text = "This was added by Room " + roomID;
        }
    }
}
