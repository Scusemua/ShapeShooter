﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {

    public GameObject bulletPrefab;

    // Normal Movements Variables
    private float walkSpeed = 4.0f;

    // Fire-rate related.
    private float fireCooldown = 0.7f;
    private float fireCooldownLeft = 0.0f;

    private Vector3 previousLocation;
    private Vector2 movementDirectionVertical;
    private Vector2 movementDirectionHorizontal;

    public GameObject floor;

    void Start()
    {
        previousLocation = this.transform.position;
    }

    void Update()
    {
        /* if (previousLocation.y < transform.position.y)
        {
            movementDirectionVertical = Vector2.up;
        }
        else
        {
            movementDirectionVertical = Vector2.down;
        }
        if (previousLocation.x < transform.position.x)
        {
            movementDirectionHorizontal = Vector2.left;
        } 
        else
        {
            movementDirectionHorizontal = Vector2.right;
        }
        previousLocation = this.transform.position; */
            
    }

    void FixedUpdate()
    {
        GetComponent<Rigidbody2D>().velocity = new Vector2(Mathf.Lerp(0, Input.GetAxis("Horizontal") * walkSpeed, 1f),
                                            Mathf.Lerp(0, Input.GetAxis("Vertical") * walkSpeed, 1f));
        // Decrement the cooldown to fire.
        fireCooldownLeft -= Time.deltaTime;
        if (fireCooldownLeft < 0) fireCooldownLeft = 0;

        if (fireCooldownLeft == 0)
        {
            if (Input.GetKey("up"))
            {
                shoot(Vector2.up);
            }
            else if (Input.GetKey("down"))
            {
                shoot(Vector2.down);
            }
            else if (Input.GetKey("right"))
            {
                shoot(Vector2.right);
            }
            else if (Input.GetKey("left"))
            {
                shoot(Vector2.left);
            }
        }
    }

    // Create an instance of a bullet and assign to it the correct direction.
    private void shoot(Vector2 direction)
    {
        GameObject bulletGO = (GameObject)Instantiate(bulletPrefab, this.transform.position, this.transform.rotation);
        fireCooldownLeft += fireCooldown;
        Bullet bullet = bulletGO.GetComponent<Bullet>();
        // bullet.GetComponent<Rigidbody2D>().AddRelativeForce(movementDirectionHorizontal, ForceMode2D.Impulse);
        // bullet.GetComponent<Rigidbody2D>().AddRelativeForce(movementDirectionVertical, ForceMode2D.Impulse);
        bullet.dir = direction;
    }
}

