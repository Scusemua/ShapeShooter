﻿using UnityEngine;
using System.Collections;

public class BasicEnemy : BaseEnemy
{   
    // The enemy will move towards the target's transform.      
    private Transform targetTransform;  

	// Use this for initialization
	void Start () {
        base.Create();
        movementSpeed = 3.5f;
        maxHealth = 3.0f;
        targetTransform = player.transform;
        health = maxHealth;
    }
	
	// Update is called once per frame
	void Update () {
        targetTransform = player.transform;
        transform.position = Vector2.MoveTowards(transform.position, targetTransform.position, movementSpeed * Time.deltaTime);
    }
}
